#!/usr/bin/env python
# Created by "Thieu" at 11:34, 11/07/2021 ----------%
#       Email: nguyenthieu2102@gmail.com            %
#       Github: https://github.com/thieu1995        %
# --------------------------------------------------%

import numpy as np
from mealpy import FloatVar, BBO
from mealpy.utils.visualize import *

## Define your own fitness function
# Multi-objective but single fitness/target value. By using weighting method to convert from multiple objectives to single target

def fitness_function(solution):
    f1 = (np.sum(solution ** 2) - np.mean(solution)) / len(solution)
    f2 = np.sum(np.sqrt(np.abs(solution)))
    f3 = np.sum(np.mean(solution ** 2) - solution)
    return [f1, f2, f3]


problem = {
    "fit_func": fitness_function,
    "bounds": FloatVar(lb=[-10, -5, -15, -20, -10, -15, -10, -30], ub=[10, 5, 15, 20, 50, 30, 100, 85]),
    "minmax": "min",
    "obj_weights": [0.2, 0.5, 0.3],
    "save_population": True
}

## Run the algorithm
model = BBO.OriginalBBO(epoch=100, pop_size=50)
g_best = model.solve(problem)
print(f"Best solution: {g_best.solution}, Best fitness: {g_best.fitness}")

## Drawing trajectory of some agents in the first and second dimensions
# Need a little bit more pre-processing
pos_list = []
list_legends = []
dimension = 2
y_label = f"x{dimension + 1}"
for i in range(0, 5, 2):  # Get the third dimension of position of the first 3 solutions
    x = [pop[0].solution[dimension] for pop in model.history.list_population]
    pos_list.append(x)
    list_legends.append(f"Agent {i + 1}.")
    # pop[0]: Get the first solution
    # pop[0][0]: Get the position of the first solution
    # pop[0][0][0]: Get the first dimension of the position of the first solution
export_trajectory_chart(pos_list, list_legends=list_legends, y_label=y_label)

# Parameter for this function
# data: is the list of array, each element is the position value of selected dimension in all generations
# title: title of the figure, default = "Trajectory of some first agents after generations"
# list_legends: list of line's name, default = None
# list_styles: matplotlib API, default =  None
# list_colors: matplotlib API, default = None
# x_label: string, default = "#Iteration"
# y_label: string, default = "X1"
# filename: string, default = "1d_trajectory"
# exts: matplotlib API, default = (".png", ".pdf") --> save figure in format of png and pdf
# verbose: show the figure on Python IDE, default = True
